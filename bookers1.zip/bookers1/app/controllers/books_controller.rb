class BooksController < ApplicationController

  def new
  end

  def index
    @BOOKERS = Book.new
    @BOOKERZ = Book.all
  end

  def show
    @BOOKERS_SHOW = Book.find(params[:id])
  end

  def edit
    @BOOKERS_EDIT = Book.find(params[:id])
  end

  def update
    @BOOKERS_EDIT = Book.find(params[:id])
      if @BOOKERS_EDIT.update(book_params)
        flash[:success] = "Book was successfully created."
        redirect_to book_path(@BOOKERS_EDIT.id)
      else
        render :edit
      end
  end

  def create
    @BOOKERS = Book.new(book_params)
      if @BOOKERS.save
        flash[:success] = "Book was successfully saved."
        redirect_to book_path(@BOOKERS.id)
      else
        @BOOKERZ = Book.all
        render :index
      end
  end

  def destroy
    book = Book.find(params[:id])
    book.destroy
    flash[:success] = "Book was successfully deleted."
    redirect_to books_path
  end

  private
  #strong parameter
  def book_params
    params.require(:book).permit(:title, :body)
  end

end